$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"f40d77a1-793f-45e4-b096-4ee62aeaf8b2","feature":"Search Functionality of Blog feature in Automation Testing Website","scenario":"Search a topic to learn in the research field of blog tab","start":1717668794819,"group":1,"content":"","tags":"","end":1717668816207,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});