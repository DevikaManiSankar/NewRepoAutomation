package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;
	
	public static ExtentReports createInstance() {
		String reportName = "Test Report.html";
		spark = new ExtentSparkReporter(System.getProperty("user.dir")+"//reports//"+reportName);
		
		spark.config().setDocumentTitle("Extent Report");
		spark.config().setReportName("Test Report");
		spark.config().setTimelineEnabled(true);
		spark.config().setTheme(Theme.DARK);
		spark.config().setTimeStampFormat("MM/dd/yyyy HH:mm:ss");
		
		extent = new ExtentReports();
		extent.attachReporter(spark);
		extent.setSystemInfo("OS", "Windows");
		extent.setSystemInfo("username","Devika");
		
		return extent;
		
		
	}

}
