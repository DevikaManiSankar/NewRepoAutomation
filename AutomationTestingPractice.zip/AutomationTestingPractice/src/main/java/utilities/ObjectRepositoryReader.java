package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class ObjectRepositoryReader {
	public static WebDriver driver;
	private static Properties prop;

	public static Properties initProperties() throws IOException {
		if (prop == null) {
			prop = new Properties();
			try {
				FileInputStream fis = new FileInputStream(
						System.getProperty("user.dir") + "\\src\\test\\resources\\object_reader\\object.properties");
				prop.load(fis);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return prop;
	}

	public static WebDriver getChromeDriver() {
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--disable-notifications");
		co.addArguments("--disable-infobars");
		co.addArguments("--start-maximized");
		co.addArguments("--disable-translate");
		
		driver = new ChromeDriver(co);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		return driver;

	}

	public static WebDriver getEdgeDriver() {
		EdgeOptions co = new EdgeOptions();
		co.addArguments("--disable-notifications");
		co.addArguments("--disable-infobars");
		co.addArguments("--start-maximized");
		co.addArguments("--disable-translate");
		driver = new EdgeDriver(co);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		return driver;

	}

}
