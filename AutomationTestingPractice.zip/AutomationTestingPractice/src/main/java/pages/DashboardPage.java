package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;

public class DashboardPage {
	WebDriver driver;
	ReusableFunctions rf;
	public DashboardPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		rf = new ReusableFunctions(driver);
	}
	
	@FindBy(linkText="blog")
	public WebElement blogLink;
	
	
	public BlogPage clickBlog(WebElement el) {
		rf.clickElement(el);
		return new BlogPage(driver);
	}
	
	

}
