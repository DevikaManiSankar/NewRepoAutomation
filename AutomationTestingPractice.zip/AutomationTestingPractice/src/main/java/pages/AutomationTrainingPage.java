package pages;

public class AutomationTrainingPage {

}
