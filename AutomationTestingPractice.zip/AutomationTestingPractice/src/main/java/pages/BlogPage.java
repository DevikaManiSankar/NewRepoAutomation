package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;

public class BlogPage {
	WebDriver driver;
	ReusableFunctions rf;
	public BlogPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		rf = new ReusableFunctions(driver);
	}
	
	@FindBy(id="search-query")
	public WebElement searchField;
	
	@FindBy(css="div:nth-child(1) > form > button")
	public WebElement searchBtn;
	
	
	
	public void enterText(WebElement el,String txt) {
		rf.insertText(el, txt);
	}
	public void clickSearch(WebElement el) {
		rf.clickElement(el);
	}
	public boolean checkUrl(String url) {
		return rf.checkurl(url);
	}
	
}
