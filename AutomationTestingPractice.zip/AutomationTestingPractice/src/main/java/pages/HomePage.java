package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;

public class HomePage {
	WebDriver driver;
	ReusableFunctions rf;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
	}

	@FindBy(linkText = "Contact")
	public WebElement contactLink;

	@FindBy(css = "#main-navbar > a")
	public WebElement AutomationTrainingLink;


	public ContactPage clickContact(WebElement element) {
		rf.clickElement(element);
		return new ContactPage(driver);

	}

	public DashboardPage clickAutomationTraining(WebElement element) {
		rf.clickElement(element);
		return new DashboardPage(driver);
	}

}
