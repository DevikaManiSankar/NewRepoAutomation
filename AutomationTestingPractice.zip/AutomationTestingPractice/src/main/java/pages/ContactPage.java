package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;

public class ContactPage {
	WebDriver driver;
	ReusableFunctions rf;

	public ContactPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
	}

	@FindBy(xpath = "//div[@class='mb-3']//input[1]")
	public WebElement name;

	@FindBy(css = " div:nth-child(2) > div:nth-child(1) > input:nth-child(2)")
	public WebElement email;

	@FindBy(name = "address")
	public WebElement message;

	@FindBy(css = ".btn.btn-primary.px-4.me-3")
	public WebElement sendBtn;

	public void enterText(WebElement el, String txt) {
		rf.insertText(el, txt);
	}

	public void clickBtn(WebElement el) {
		rf.clickElement(el);
	}
	public void scrollTo(WebElement el) {
		rf.scroll(el);
	}
	public boolean checkurl(String url) {
		return rf.checkurl(url);
	}
}
