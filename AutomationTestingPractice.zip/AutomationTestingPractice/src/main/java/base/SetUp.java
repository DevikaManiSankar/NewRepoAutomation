package base;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hpsf.Date;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import utilities.ObjectRepositoryReader;

public class SetUp {
	public static WebDriver driver;
	public static Properties prop;
	public static String browser_choice;

	public SetUp() throws IOException {
		prop = ObjectRepositoryReader.initProperties();
	}

	public static WebDriver invokeBrowser() {
		browser_choice = prop.getProperty("browser");
		try {
			if (browser_choice.equalsIgnoreCase("chrome")) {
				driver = ObjectRepositoryReader.getChromeDriver();
			} else if (browser_choice.equalsIgnoreCase("edge")) {
				driver = ObjectRepositoryReader.getEdgeDriver();
			} else {
				throw new Exception("Invalid browser name ! ");
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return driver;

	}

	public static void takeScreenshot(String filepath) {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File srcFile = ts.getScreenshotAs(OutputType.FILE);
		File destFile = new File(filepath);
		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}

}
