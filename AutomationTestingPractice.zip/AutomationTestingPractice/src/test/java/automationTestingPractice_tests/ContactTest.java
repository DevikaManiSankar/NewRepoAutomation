package automationTestingPractice_tests;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.SetUp;
import pages.ContactPage;
import pages.HomePage;
import utilities.ExcelReader;
import utilities.ExtentReportListener;

@Listeners(ExtentReportListener.class)
public class ContactTest extends SetUp {
	HomePage hp;
	ContactPage cp;

	public ContactTest() throws IOException {
		super();

	}

	// calls the invokeBrowser method of SetUp class
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("BaseUrl")); // gets the base url in object.properties file
		hp = new HomePage(driver);
	}

	@AfterTest
	public void teardown() {
		driver.quit();
	}

	// clicking send button without providing any data
	@Test(priority = 0)
	public void clickSendWithoutData() {
		cp = hp.clickContact(hp.contactLink); // clicks the 'contact' link in home page and moves to contact page
		cp = new ContactPage(driver);
		cp.scrollTo(cp.sendBtn);
		cp.clickBtn(cp.sendBtn);
		// checks if the user stays in the same page - if true : test passed !
		assertTrue(cp.checkurl(prop.getProperty("contactUrl")), "Contact Test with null data failed !");
	}

	// clicking send button after providing data from excel sheet
	@Test(priority = 1, dataProvider = "contact_validation")
	public void clickSendWithData(String name, String email, String message) {
		// filling the name,email and message fields using excel
		cp.enterText(cp.name, name);
		cp.enterText(cp.email, email);
		cp.enterText(cp.message, message);
		cp.clickBtn(cp.sendBtn);
		// if user stays in the same page , then test failed
		assertFalse(cp.checkurl(prop.getProperty("contactUrl")), "Message not sent");

	}

	@DataProvider
	public String[][] contact_validation() throws IOException {
		String path = System.getProperty("user.dir") + "\\data_source\\dataset.xlsx";
		String sheetname = "contact";
		String[][] data = ExcelReader.getExcelData(path, sheetname);
		return data;

	}
}
