package step_definitions;

import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.BlogPage;
import pages.DashboardPage;
import pages.HomePage;

public class SearchTest {
	WebDriver driver = Hooks.driver;
	Properties prop = Hooks.prop;
	HomePage hp;
	DashboardPage dp;
	BlogPage bp;
	
	@Given("the user in the blog page")
	public void the_user_in_the_blog_page() {
	    hp = new HomePage(driver);
	    driver.get(prop.getProperty("BaseUrl"));
	    dp = hp.clickAutomationTraining(hp.AutomationTrainingLink);
	    
	    bp = dp.clickBlog(dp.blogLink);
	    
	    
	}
	@Given("the user enters the text to search in the research field")
	public void the_user_enters_the_text_to_search_in_the_research_field() {
	    bp.enterText(bp.searchField,prop.getProperty("searchtext"));
	    bp.clickSearch(bp.searchBtn);
	}
	@Given("user clicks the To research button")
	public void user_clicks_the_button() {
		bp.clickSearch(bp.searchBtn);
	}
	@Then("the search results are displayed")
	public void the_search_results_are_displayed() {
	   assertTrue(driver.getCurrentUrl().contains(prop.getProperty("searchValidate")));
	}


}
