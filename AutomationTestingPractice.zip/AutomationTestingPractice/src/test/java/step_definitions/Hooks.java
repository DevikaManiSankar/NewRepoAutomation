package step_definitions;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	 static WebDriver driver;
	 static Properties prop;
	 String config_path = System.getProperty("user.dir")+"\\src\\test\\resources\\object_reader\\object.properties";
	 
	 @Before
		public void setupdriver() {
			prop = new Properties();
			try (FileInputStream fis = new FileInputStream(config_path)) {
				prop.load(fis);
			} catch (Exception e) {
				
				e.printStackTrace();
			}

			String driverType = prop.getProperty("browser");
			if (driverType.equals("chrome")) {
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-notifications");
				options.addArguments("--start-maximized");
				driver = new ChromeDriver(options);
			} else if (driverType.equals("edge")) {
				EdgeOptions options = new EdgeOptions();
				options.addArguments("--disable-notifications");
				options.addArguments("--start-maximized");
				driver = new EdgeDriver(options);
			}
			
		}

		@After
		public void teardown() {
			driver.quit();
		}


}
